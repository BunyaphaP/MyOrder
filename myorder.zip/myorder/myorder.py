from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from datetime import date
import sqlite3
import time

def main():
    root = Tk()
    root.title("MY ORDER APPLICATION")
    w = root.winfo_screenwidth()
    h = root.winfo_screenheight()
    root.geometry("%dx%d"%(w,h))
    root.columnconfigure(0,weight=1)
    root.rowconfigure(0,weight=1)
    return root

def createconnection() :
    global conn,cursor
    conn = sqlite3.connect('myorder.db')
    cursor = conn.cursor()

def login(root):
    global loginframe,myorder_logo,cus_code_entry
    loginframe = Frame(root,bg="#de8971")
    loginframe.grid(column=0,row=0,sticky='news')
    loginframe.rowconfigure((0,1,2,3,4),weight=1)
    loginframe.columnconfigure((0,1,2),weight=1)
    
    myorder_logo=PhotoImage(file="img/logo.png").subsample(2,2)
    Label(loginframe,image=myorder_logo,bg="#de8971").grid(column=0,row=0,columnspan=3)
    
    Label(loginframe,text="M Y  O R D E R",bg="#de8971",fg="#7b6079",
    font="Aller 45 bold").grid(column=0,row=1,columnspan=3)
    
    Label(loginframe,text="CODE :",bg="#de8971",fg="white",font="Courier 25 bold").grid(column=0,row=2,sticky=E)

    cus_code_entry = Entry(loginframe,width=10,font="Courier 30",justify=CENTER)
    cus_code_entry.grid(column=1,row=2,padx=10,ipady=7)
    
    Button(loginframe,text="OK",bg="#7b6079",fg="white",
    font="Courier 20",command=loginclick).grid(column=2,row=2,ipady=7,ipadx=50,sticky=W)

    Button(loginframe,text="Customer Data",bg="#a7d0cd",command=customer_data,
    font="Courier 20 bold").grid(column=0,row=4,ipady=10,padx=10,ipadx=15,sticky=E)
    Button(loginframe,text="New Customer",bg="#ffe9d6",command = new_customer,
    font="Courier 20 bold").grid(column=1,row=4,ipady=10,padx=10,ipadx=15)
    Button(loginframe,text="Product Data",bg="lightgrey",command=prod_data,
    font="Courier 20 bold").grid(column=2,row=4,ipady=10,padx=10,ipadx=15,sticky=W)

def loginclick():
    global result
    if cus_code_entry.get() == "" :
        messagebox.showwarning("My Order :","Enter Customer's Code!!")
    else :
        sql = "select * from customer where cus_id=?"                    
        cursor.execute(sql,[cus_code_entry.get()])                      
        result = cursor.fetchone()
        if result :
            messagebox.showinfo("System :","Success!")
            menu_order(cus_code_entry.get())
        else :
            messagebox.showerror("System :","Customer not founded :(")

def clock():
    global hour,minute,sec,today
    hour = time.strftime("%H")
    minute = time.strftime("%M")
    sec = time.strftime("%S")
    today = date.today()

def logout_from_menu():
    menubar.destroy()
    menu_order_frame.destroy()
    login(root)
    root.title("MY ORDER APPLICATION")

def logout_from_new_cus():
    new_customer_frame.destroy()
    login(root)
    root.title("MY ORDER APPLICATION")

def menu_menu():
    global menuframe
    loginframe.destroy()
    
    menuframe = Frame(menu_order_frame,bg="#7b6079")
    menuframe.rowconfigure((0,1),weight=1)
    menuframe.columnconfigure((0,1),weight=1)
    menuframe.grid(column=0,row=0,sticky='news')

    Button(menuframe,text="ORDER",font="Terminal 25",
    width=23,bg="#de8971",command=menu_order_product).grid(row=0,column=0,ipady=5,padx=10,pady=10)
    Button(menuframe,text="CART",font="Terminal 25",
    width=23,bg="#de8971",command=menu_cart).grid(row=0,column=1,ipady=5,padx=10,pady=10)

def menu_order(user):
    global menu_order_frame,menubar
    loginframe.destroy()
    
    menu_order_frame = Frame(root,bg="#7b6079")
    menu_order_frame.grid(column=0,row=0,sticky='news')
    menu_order_frame.rowconfigure(0,weight=1)
    menu_order_frame.rowconfigure(1,weight=3)
    menu_order_frame.columnconfigure(0,weight=1)

    root.title("CUSTOMER : " + result[1] + " " + result[2] )
    menubar = Menu()
    root.config(menu=menubar)
    menubar.add_command(label="Menu",command=lambda:menu_order(user))      
    menubar.add_command(label="EXIT",command=logout_from_menu)

    menu_menu()

def menu_cart():
    global orderbag,cash_logo,card_logo
    global total_of_order

    menu_cart_frame=Frame(menu_order_frame,bg="#fadcaa")
    menu_cart_frame.grid(column=0,row=1,sticky='news')
    menu_cart_frame.columnconfigure((0,1,2,3),weight=1)
    
    card_logo = PhotoImage(file="img/card.png").subsample(6,6)
    cash_logo = PhotoImage(file="img/cash.png").subsample(6,6)

    Label(menu_cart_frame,bg="lightgrey",text=result[1] + " " + result[2],
    font="Courier 30 bold").grid(column=0,row=0,columnspan=4,sticky='news',pady=10)
    
    list = ["Product","Amount","Total"]

    for i,des in enumerate(list):
        Label(menu_cart_frame,text=des,bg="#fadcaa",font="Courier 20 bold").grid(column=i,row=1)
    
    for i,des in enumerate(order_name_lst):
        Label(menu_cart_frame,text=order_name_lst[i]+" ("+order_price_lst[i]+" THB)",
        bg="#fadcaa",font="Courier 15").grid(column=0,row=i+2,sticky=W,padx=50)
        Label(menu_cart_frame,text=str(order_amt_lst[i]),
        bg="#fadcaa",font="Courier 15").grid(column=1,row=i+2)
        Label(menu_cart_frame,text=str(order_tt_lst[i]),
        bg="#fadcaa",font="Courier 15").grid(column=2,row=i+2)
        Button(menu_cart_frame,text="remove",fg="white",command=remove_cart,
        bg="darkred",font="Courier 15").grid(column=3,row=i+2,pady=15)

    Label(menu_cart_frame,text="Payment : ",bg="#fadcaa",font="Courier 20 bold").grid(column=0,row=len(order_name_lst)+3)
    Radiobutton(menu_cart_frame,text="  Card",image=card_logo,bg="#fadcaa",variable=payment_var,value="card",
    font="Courier 20",compound=LEFT).grid(column=1,row=len(order_name_lst)+3,sticky=W)
    Radiobutton(menu_cart_frame,text="  Cash",image=cash_logo,bg="#fadcaa",variable=payment_var,value="cash",
    font="Courier 20",compound=LEFT).grid(column=2,row=len(order_name_lst)+3,sticky=W)
    
    total_of_order=0
    total_of_order = sum(order_tt_lst)

    Label(menu_cart_frame,text="Total = "+str(total_of_order)+" THB",bg="lightgrey",
    font="Courier 20 bold").grid(column=0,row=len(order_name_lst)+4,columnspan=4,sticky='news')
    
    Button(menu_cart_frame,text="Confirm Order",bg="#cee6b4",command=checkout,
    font="Courier 15 bold").grid(column=0,row=len(order_name_lst)+5,ipadx=15,columnspan=4,pady=10)

def menu_order_product():
    global menu_order_tree,prod_id_box,prod_name_box,prod_price_box,prod_amt_box,search_order
    global cart

    order_frame=Frame(menu_order_frame,bg="#ffc996")
    order_frame.grid(column=0,row=1,sticky='news')
    order_frame.columnconfigure((0,1,2),weight=1)
    order_frame.rowconfigure((0,1,2,3,4,5),weight=1)

    menu_order_tree = ttk.Treeview(order_frame,columns=("product_id","product_name","product_price"),height=10)
    menu_order_tree.grid(column=0,row=1,columnspan=3,sticky='news',padx=20,pady=15)

    menu_order_scrollbar = ttk.Scrollbar(order_frame,orient=VERTICAL,command=menu_order_tree.yview)
    menu_order_scrollbar.grid(row=1, column=0,sticky='nes',columnspan=3,padx=20,pady=15)
    menu_order_tree.configure(yscrollcommand=menu_order_scrollbar.set)
  
    menu_order_tree.heading("#0",text="",anchor=W)
    menu_order_tree.heading("product_id",text="Code",anchor=CENTER)
    menu_order_tree.heading("product_name",text="Product Name",anchor=CENTER)
    menu_order_tree.heading("product_price",text="Price (1 unit) THB",anchor=CENTER)

    menu_order_tree.column("#0",width=0,stretch=NO)
    menu_order_tree.column("product_id",anchor=CENTER,width=50)
    menu_order_tree.column("product_name",anchor=CENTER,width=100)
    menu_order_tree.column("product_price",anchor=CENTER,width=50)

    style = ttk.Style()
    style.theme_use("clam")
    
    fetch_all_order()

    prod_id_box = Entry(order_frame,justify=CENTER,font="Courier 20 bold")
    prod_id_box.grid(row=2,column=0,ipady=5)
    prod_name_box = Entry(order_frame,justify=CENTER,font="Courier 20 bold")
    prod_name_box.grid(row=2,column=1,ipady=5)
    prod_price_box = Entry(order_frame,justify=CENTER,font="Courier 20 bold")
    prod_price_box.grid(row=2,column=2,ipady=5)

    Label(order_frame,text="Amount : ",font="Courier 20 bold",bg="#ffc996").grid(row=3,column=0,padx=20,sticky=E)

    prod_amt_box = Entry(order_frame,justify=CENTER,font="Courier 20 bold",width=5,bg="lightgrey",
    textvariable=prod_amt_box_var)
    prod_amt_box.grid(row=3,column=1,ipadx=2,padx=50,ipady=5,sticky=W)

    cart = PhotoImage(file="img/cart.png").subsample(7,7)
    Button(order_frame,image=cart,text=" ADD ",bg="#cee6b4",font="Courier 30",command=add_to_cart,
    compound=LEFT).grid(row=3,column=2)

    Label(order_frame,text="Product Code >>>",font="Courier 20 bold",
    bg="#ffc996").grid(row=0,column=0,sticky=E,pady=15)

    search_order = Entry(order_frame,width=20,font="Courier 20",bg="lightgrey",justify=CENTER)
    search_order.grid(row=0,column=1,columnspan=3,ipady=8,sticky=W,padx=50,pady=15)

    Button(order_frame,image=search_logo,command=search_order_click).grid(row=0,column=2,padx=20,sticky=W,pady=15)
    Button(order_frame,text='Show All',font="Courier 15",command=fetch_all_order).grid(row=0,column=2,ipady=5,ipadx=10,pady=15)

    menu_order_tree.bind('<Double-1>',treeviewclick_product)

def fetch_all_order():
    menu_order_tree.delete(*menu_order_tree.get_children())
    sql = "SELECT product_id,product_name,product_price FROM product "
    cursor.execute(sql)
    result = cursor.fetchall() 
    
    for i,data in enumerate(result):
        if i%2 == 1 :
            menu_order_tree.insert('', 'end', values=(data[0],data[1], data[2]),tags=('oddrow'))
        else :
            menu_order_tree.insert('', 'end', values=(data[0],data[1], data[2]),tags=('evenrow'))

def fetch_all_prod():
    mytree_prod.delete(*mytree_prod.get_children())
    sql = "SELECT product_id,product_name,product_price FROM product "
    cursor.execute(sql)
    result = cursor.fetchall() 
    
    for i,data in enumerate(result):
        if i%2 == 1 :
            mytree_prod.insert('', 'end', values=(data[0],data[1], data[2]),tags=('oddrow'))
        else :
            mytree_prod.insert('', 'end', values=(data[0],data[1], data[2]),tags=('evenrow'))

def fetch_all_cus():
    mytree.delete(*mytree.get_children())
    sql = "SELECT * FROM customer"
    cursor.execute(sql)
    result = cursor.fetchall() 
    
    for i,data in enumerate(result):
        if i%2 == 1 :
            mytree.insert('', 'end', values=(data[0],data[1], data[2], data[3], 
            data[4],data[5],data[6],data[7]),tags=('oddrow'))
        else :
            mytree.insert('', 'end', values=(data[0],data[1], data[2], data[3], 
            data[4],data[5],data[6],data[7]),tags=('evenrow'))

def treeviewclick_product(event):
    prod_id_box['state']='normal'
    prod_name_box['state']='normal'
    prod_price_box['state']='normal'

    prod_id_box.delete(0,END)
    prod_name_box.delete(0,END)
    prod_price_box.delete(0,END)
    prod_amt_box.delete(0,END)

    values_order = menu_order_tree.item(menu_order_tree.focus(),'values')

    prod_id_box.insert(0,values_order[0])
    prod_name_box.insert(0,values_order[1])
    prod_price_box.insert(0,values_order[2])

    prod_id_box['state']='disable'
    prod_name_box['state']='disable'
    prod_price_box['state']='disable'

def add_to_cart():
    check=prod_amt_box_var.get()
    cal_price=prod_price_box.get()
    name_get=prod_name_box.get()
    amt_int=prod_amt_box.get()

    if prod_amt_box_var.get()=="":
        pass
    elif check.isalpha() :
        pass
    else :
        if name_get in order_name_lst :
            loc_lst_name= order_name_lst.index(name_get)
            value = order_amt_lst[loc_lst_name]
            sum_amt = int(value)+int(amt_int)
            order_amt_lst[loc_lst_name]=sum_amt
            messagebox.showinfo("SYSTEM","Order added!")
            total = int(cal_price)*sum_amt
            order_tt_lst[loc_lst_name]=total
        else:
            order_name_lst.append(name_get)
            order_price_lst.append(prod_price_box.get())
            order_amt_lst.append(prod_amt_box.get())
            messagebox.showinfo("SYSTEM","Order added!")
            total = (int(cal_price))*int(amt_int)
            order_tt_lst.append(total)

    prod_amt_box.delete(0,END)

def search_order_click():  
    menu_order_tree.delete(*menu_order_tree.get_children())
    sql = "select * from product where product_id=?"
    cursor.execute(sql,[search_order.get()])
    result = cursor.fetchall()
    if result :
        for i,data in enumerate(result):
            menu_order_tree.insert('','end',values=(data[0],data[1],data[2]))

def remove_cart():
    i=2
    order_name_lst.remove(order_name_lst[i-2])
    order_amt_lst.remove(order_amt_lst[i-2])
    order_tt_lst.remove(order_tt_lst[i-2])
    messagebox.showinfo("SYSTEM :","This product has removed from the cart.")

def new_customer():
    global regispic,new_customer_frame,new_cus_name,new_cus_surname,new_cus_address,new_cus_phone
    loginframe.destroy()
    root.title("MY ORDER : New Customer Registration")

    new_customer_frame = Frame(root,bg="#ffe9d6")
    new_customer_frame.columnconfigure((0,1,2),weight=1)
    new_customer_frame.rowconfigure((0,1,2,3,4),weight=1)
    new_customer_frame.grid(column=0,row=0,sticky='news')

    Label(new_customer_frame,text="New Customer Registration",bg="#ffe9d6",
    font="Courier 40 bold").grid(column=0,row=0,columnspan=3)
    
    new_customer_info_lst=["Name-Surname : ","Address : ","Phone   : "]
    for i,des in enumerate(new_customer_info_lst):
        Label(new_customer_frame,text=des,bg="#ffe9d6",font="Courier 20").grid(column=0,row=i+1,padx=15,sticky=W)
    
    new_cus_name=Entry(new_customer_frame,width=25,font="Courier 20")
    new_cus_name.grid(column=1,row=1,padx=15,sticky=W)

    new_cus_surname=Entry(new_customer_frame,width=25,font="Courier 20")
    new_cus_surname.grid(column=2,row=1,sticky=W)

    new_cus_address=Text(new_customer_frame,width=25,height=4,font="Courier 20")
    new_cus_address.grid(column=1,row=2,padx=15,sticky=W)

    new_cus_phone=Entry(new_customer_frame,width=25,font="Courier 20")
    new_cus_phone.grid(column=1,row=3,padx=15,sticky=W)
    
    regispic = PhotoImage(file="img/regis_pic.png").subsample(3,3)
    Label(new_customer_frame,image=regispic,bg="#ffe9d6").grid(column=2,row=2,rowspan=2)
    
    Button(new_customer_frame,text="Cancel",font="Courier 20 bold",command=logout_from_new_cus,
    bg="darkred",fg="white",width=20).grid(column=0,row=4,padx=15)
    Button(new_customer_frame,text="Clear",font="Courier 20 bold",command=clear_cus_data,
    bg="darkblue",fg="white",width=20).grid(column=1,row=4,padx=15)
    Button(new_customer_frame,text="Save",font="Courier 20 bold",command=add_new_cus,
    bg="darkgreen",fg="white",width=20).grid(column=2,row=4,padx=15)

def customer_data():
    global customer_data_frame,cus_name_box,cus_surname_box,cus_phone_box,cus_address_box,cus_order_box,cus_tt_box,cus_date_box
    global mytree,update_btn,search_cus

    customer_data_frame = Frame(root,bg="#a7d0cd")
    customer_data_frame.columnconfigure((0,1,2),weight=1)
    customer_data_frame.rowconfigure((0,1,2,3,4,5,6,7),weight=1)
    customer_data_frame.grid(column=0,row=0,sticky='news')

    Label(customer_data_frame,text="Customer Data",font="Courier 40 bold",bg="#a7d0cd").grid(column=0,row=0,columnspan=3)
    Label(customer_data_frame,width=20)

    Label(customer_data_frame,text="Customer Name :",font="Courier 20 bold",bg="#a7d0cd").grid(column=0,row=1,sticky=E)

    search_cus = Entry(customer_data_frame,width=20,font="Courier 20",justify=CENTER,bg="lightgrey")
    search_cus.grid(row=1,column=1,ipady=8,padx=50,pady=15)

    Button(customer_data_frame,image=search_logo,command=search_cus_click).grid(row=1,column=2,padx=20,sticky=W,pady=15)
    Button(customer_data_frame,text='Show All',font="Courier 15",command=fetch_all_cus).grid(row=1,column=2,ipady=5,ipadx=10,pady=15)

    mytree = ttk.Treeview(customer_data_frame,columns=("cus_id","cus_name","cus_surname",
    "cus_address","cus_phone","cus_order","cus_tt","cus_date"),height=10)
    mytree.grid(column=0,row=2,columnspan=3,sticky='news',padx=20)

    tree_scrollbar = ttk.Scrollbar(customer_data_frame,orient=VERTICAL,command=mytree.yview)
    tree_scrollbar.grid(row=2, column=0,sticky='nes',columnspan=3,padx=20)
    mytree.configure(yscrollcommand=tree_scrollbar.set)

    mytree.heading("#0",text="",anchor=W)
    mytree.heading("cus_id",text="Customer Code",anchor=CENTER)
    mytree.heading("cus_name",text="Name",anchor=CENTER)
    mytree.heading("cus_surname",text="Surname",anchor=CENTER)
    mytree.heading("cus_address",text="Address",anchor=CENTER)
    mytree.heading("cus_phone",text="Phone",anchor=CENTER)
    mytree.heading("cus_order",text="Order",anchor=CENTER)
    mytree.heading("cus_tt",text="Total",anchor=CENTER)
    mytree.heading("cus_date",text="Date",anchor=CENTER)

    mytree.column("#0",width=0,stretch=NO)
    mytree.column("cus_id",anchor=CENTER,width=100)
    mytree.column("cus_name",anchor=CENTER,width=150)
    mytree.column("cus_surname",anchor=CENTER,width=150)
    mytree.column("cus_address",anchor=CENTER,width=200)
    mytree.column("cus_phone",anchor=CENTER,width=70)
    mytree.column("cus_order",anchor=CENTER,width=200)
    mytree.column("cus_tt",anchor=CENTER,width=70)
    mytree.column("cus_date",anchor=CENTER,width=100)

    fetch_all_cus()

    cus_name_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_name_box.grid(row=3,column=0,ipady=10,pady=10)
    cus_surname_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_surname_box.grid(row=3,column=1,ipady=10,pady=10)
    cus_phone_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_phone_box.grid(row=3,column=2,ipady=10,pady=10)

    cus_address_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_address_box.grid(row=4,column=0,ipady=10,pady=10,columnspan=2,ipadx=230,padx=50,sticky=W)
    cus_order_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_order_box.grid(row=5,column=0,columnspan=2,ipady=10,pady=10,ipadx=230,padx=50,sticky=W)

    cus_tt_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_tt_box.grid(row=6,column=0,ipady=10,padx=20,pady=10)
    cus_date_box = Entry(customer_data_frame,justify=CENTER,font="Courier 20 bold")
    cus_date_box.grid(row=6,column=1,ipady=10,padx=20,pady=10)

    update_btn = Button(customer_data_frame,text="Update",bg="yellow",
    font="Courier 20 bold",command=update_cus_data,width=10)
    update_btn.grid(column=2,row=4,pady=10)
    Button(customer_data_frame,text="Delete",bg="darkred",font="Courier 20 bold",command=remove_cus,
    fg='white',width=10).grid(column=2,row=5,pady=10)
    Button(customer_data_frame,text="Back",bg="#ffe9d6",font="Courier 20 bold",command=back_from_cus_data,
    width=10).grid(column=2,row=6)

    mytree.bind('<Double-1>',treeviewclick)

def search_cus_click():  
    mytree.delete(*mytree.get_children())
    sql = "select * from customer where cus_name=?"
    cursor.execute(sql,[search_cus.get()])
    result = cursor.fetchall()
    if result :
        for i,data in enumerate(result):
            mytree.insert('','end',values=(data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7]))

def back_from_cus_data():
    customer_data_frame.destroy()
    login(root)

def treeviewclick(event):
    cus_name_box.delete(0,END)
    cus_surname_box.delete(0,END)
    cus_phone_box.delete(0,END)
    cus_address_box.delete(0,END)
    cus_order_box.delete(0,END)
    cus_tt_box.delete(0,END)
    cus_date_box.delete(0,END)

    values = mytree.item(mytree.focus(),'values')

    cus_name_box.insert(0,values[1])
    cus_surname_box.insert(0,values[2])
    cus_phone_box.insert(0,values[4])
    cus_address_box.insert(0,values[3])
    cus_order_box.insert(0,values[5])
    cus_tt_box.insert(0,values[6])
    cus_date_box.insert(0,values[7])

def update_cus_data() :
    update_mytree = mytree.item(mytree.focus(),'values')

    sql = '''UPDATE customer
             SET cus_name=?, cus_surname=?, cus_phone=?, cus_address=?, cus_order=?, cus_tt=?, cus_date=?
             WHERE cus_id=?'''
    cursor.execute(sql,[cus_name_box.get(),cus_surname_box.get(),cus_phone_box.get(),
    cus_address_box.get(),cus_order_box.get(),cus_tt_box.get(),cus_date_box.get(),update_mytree[0]])  
    conn.commit()

    messagebox.showinfo("Customer Record","UPDATE Successfully!")

def remove_cus() :
    msg = messagebox.askquestion ('SYSTEM :','Are you sure you want to delete this customer?',icon = 'warning')
    if msg == 'no':
        cus_name_box.delete(0,END)
        cus_surname_box.delete(0,END)
        cus_phone_box.delete(0,END)
        cus_address_box.delete(0,END)
        cus_order_box.delete(0,END)
        cus_tt_box.delete(0,END)
        cus_date_box.delete(0,END)
    else:
        deleterow = mytree.selection()
        values = mytree.item(mytree.focus(),'values')
        mytree.delete(deleterow)
        
        sql = "DELETE FROM customer WHERE cus_id=?"
        cursor.execute(sql,[values[0]])
        conn.commit()

        cus_name_box.delete(0,END)
        cus_surname_box.delete(0,END)
        cus_phone_box.delete(0,END)
        cus_address_box.delete(0,END)
        cus_order_box.delete(0,END)
        cus_tt_box.delete(0,END)
        cus_date_box.delete(0,END)

def add_new_cus() :
    sql = 'INSERT INTO customer(cus_name,cus_surname,cus_phone,cus_address) VALUES (?,?,?,?)'
    cursor.execute(sql,[new_cus_name.get(),new_cus_surname.get(),new_cus_phone.get(),new_cus_address.get(1.0,END)])
    conn.commit()
    messagebox.showinfo("New Customer","Your New Customer was added.")

def clear_cus_data():
    new_cus_name.delete(0,END)
    new_cus_surname.delete(0,END)
    new_cus_address.delete(1.0,END)
    new_cus_phone.delete(0,END)

def checkout():
    global box_logo,checkoutframe

    menuframe.destroy()
    menubar.destroy()
    
    checkoutframe = Frame(root,bg="#C5A9B0")
    checkoutframe.columnconfigure((0,1,2,3),weight=1)
    checkoutframe.grid(column=0,row=0,sticky='news')

    box_logo=PhotoImage(file="img/box.png").subsample(4,4)
    Label(checkoutframe,image=box_logo,bg="#C5A9B0").grid(column=0,row=0,columnspan=4)

    Label(checkoutframe,text="Order Summary",font="Courier 40 bold",bg="#C5A9B0").grid(column=0,row=1,columnspan=4,padx=25)
    Label(checkoutframe,text="Customer Name :",font="Courier 14 bold",bg="#C5A9B0").grid(column=0,row=2,
    padx=15,sticky=W)
    Label(checkoutframe,text=result[1]+" "+result[2],font="Courier 14",bg="#C5A9B0").grid(column=1,row=2,
    padx=15,sticky=W)
    Label(checkoutframe,text="Date/Time :",font="Courier 14 bold",bg="#C5A9B0").grid(column=0,row=3,
    padx=15,sticky=W)
    
    Label(checkoutframe,text=str(today) + " | "+hour + " : "+minute + " : "+sec,
    font="Courier 14",bg="#C5A9B0").grid(column=1,row=3,padx=15,sticky=W)

    Label(checkoutframe,text="Payment :   ",font="Courier 14 bold",bg="#C5A9B0").grid(column=0,row=4,
    padx=15,sticky=W)
    Label(checkoutframe,text=str(payment_var.get()),font="Courier 14",bg="#C5A9B0").grid(column=1,row=4,
    padx=15,sticky=W)

    sum_list = ["PRODUCT","AMOUNT","PRICE","TOTAL"]

    for i,des in enumerate(sum_list):
        Label(checkoutframe,text=des,font="Courier 20 bold",bg="#C5A9B0").grid(column=i,row=5,padx=10)

    for i,des in enumerate(order_name_lst):
        Label(checkoutframe,text=order_name_lst[i],font="Courier 20",bg="#C5A9B0").grid(column=0,row=i+6,padx=10)
        Label(checkoutframe,text=order_amt_lst[i],font="Courier 20",bg="#C5A9B0").grid(column=1,row=i+6,padx=10)
        Label(checkoutframe,text=order_price_lst[i],font="Courier 20",bg="#C5A9B0").grid(column=2,row=i+6,padx=10)
        Label(checkoutframe,text=order_tt_lst[i],font="Courier 20",bg="#C5A9B0").grid(column=3,row=i+6,padx=10)

    Label(checkoutframe,text="Total = "+(str(total_of_order))+" THB",font="Courier 20 bold",
    bg="lightgrey").grid(column=0,row=i+7,columnspan=4,sticky='news')

    Button(checkoutframe,text="SAVE",font="Courier 20 bold",bg="darkgreen",fg="white",command=saveorder).grid(column=0,row=i+8,
    padx=15,columnspan=4,pady=15)

def saveorder():
    global order_tt_lst_sql
    global order_lst_sql

    payment_get=payment_var.get()
    day_sql=str(today)
    time_sql=str(hour)+":"+str(minute)+":"+str(sec)
    
    if order_name_lst==[]:
        messagebox.showinfo("SYSTEM","No order data.")
    else:
        for i,des in enumerate(order_name_lst):
            order_adding = str(order_name_lst[i])+":"+str(order_amt_lst[i])+","
            order_lst_sql.append(order_adding)
        fin_order_lst= " ".join(order_lst_sql)

        total_adding=str(sum(order_tt_lst))+" THB"
        date_sql = "("+payment_get+")"+"-"+day_sql+","+time_sql
        order_date_sql.append(date_sql)
        order_tt_lst_sql.append(total_adding)
  
        sql = '''UPDATE customer
                SET cus_order=?, cus_tt=?, cus_date=?
                WHERE cus_id=?'''
        cursor.execute(sql,[fin_order_lst,order_tt_lst_sql[0],order_date_sql[0],result[0]])
        conn.commit()

        order_confirm_page()

def order_confirm_page():
    global confirm_logo,order_confirm_frame

    checkoutframe.destroy()

    order_confirm_frame=Frame(root,bg="#de8971")
    order_confirm_frame.grid(column=0,row=0,sticky='news')
    order_confirm_frame.rowconfigure((0,1,2),weight=1)
    order_confirm_frame.columnconfigure(0,weight=1)

    confirm_logo=PhotoImage(file="img/final.png").subsample(3,3)

    Label(order_confirm_frame,bg="#de8971",imag=confirm_logo).grid(column=0,row=0)
    Label(order_confirm_frame,bg="#de8971",text="System has recorded\n"+result[1]+" "+result[2]+"'s order!",
    font="Garamond 40 bold").grid(column=0,row=1)
    Button(order_confirm_frame,text="Exit",command=exit_from_confirm,font="Courier 20 bold").grid(column=0,row=2,ipadx=20)

def exit_from_confirm():
    login(root)
    root.title("MY ORDER APPLICATION")

def prod_data():
    global add_prod_frame,prod_id_prod_data,prod_name_prod_data,prod_price_prod_data,search_product
    global tree_prod_scrollbar,mytree_prod

    add_prod_frame = Frame(root,bg="lightgrey")
    add_prod_frame.columnconfigure((0,1,2),weight=1)
    add_prod_frame.rowconfigure((0,1,2,3,4,5,6),weight=1)
    add_prod_frame.grid(column=0,row=0,sticky='news')

    Label(add_prod_frame,text="Product Data",font="Courier 40 bold",bg="lightgrey").grid(column=0,row=0,columnspan=3)
    Label(add_prod_frame,width=20)

    Label(add_prod_frame,text="Product Code >>>",font="Courier 20 bold",bg="lightgrey").grid(column=0,row=1,sticky=E)

    search_product = Entry(add_prod_frame,width=20,font="Courier 20",justify=CENTER)
    search_product.grid(row=1,column=1,ipady=8,padx=50,pady=15)

    Button(add_prod_frame,image=search_logo,command=search_product_click).grid(row=1,column=2,padx=20,sticky=W,pady=15)
    Button(add_prod_frame,text='Show All',font="Courier 15",command=fetch_all_prod).grid(row=1,column=2,ipady=5,ipadx=10,pady=15)

    mytree_prod = ttk.Treeview(add_prod_frame,columns=("product_id","product_name","product_price"),height=10)
    mytree_prod.grid(column=0,row=3,columnspan=3,sticky='news',padx=20)

    tree_prod_scrollbar = ttk.Scrollbar(add_prod_frame,orient=VERTICAL,command=mytree_prod.yview)
    tree_prod_scrollbar.grid(row=3, column=0,sticky='nes',columnspan=3,padx=20)
    mytree_prod.configure(yscrollcommand=tree_prod_scrollbar.set)

    mytree_prod.heading("#0",text="",anchor=W)
    mytree_prod.heading("product_id",text="Product Code",anchor=CENTER)
    mytree_prod.heading("product_name",text="Name",anchor=CENTER)
    mytree_prod.heading("product_price",text="Price (THB)",anchor=CENTER)

    mytree_prod.column("#0",width=0,stretch=NO)
    mytree_prod.column("product_id",anchor=CENTER,width=100)
    mytree_prod.column("product_name",anchor=CENTER,width=150)
    mytree_prod.column("product_price",anchor=CENTER,width=100)

    sql = "SELECT * FROM product"
    cursor.execute(sql)
    result = cursor.fetchall() 
    
    for i,data in enumerate(result):
        if i%2 == 1 :
            mytree_prod.insert('', 'end', values=(data[0],data[1], data[2]),tags=('oddrow'))
        else :
            mytree_prod.insert('', 'end', values=(data[0],data[1], data[2]),tags=('evenrow'))

    prod_id_prod_data = Entry(add_prod_frame,justify=CENTER,font="Courier 20 bold")
    prod_id_prod_data.grid(row=4,column=0,ipady=10)
    prod_name_prod_data = Entry(add_prod_frame,justify=CENTER,font="Courier 20 bold")
    prod_name_prod_data.grid(row=4,column=1,ipady=10)
    prod_price_prod_data = Entry(add_prod_frame,justify=CENTER,font="Courier 20 bold")
    prod_price_prod_data.grid(row=4,column=2,ipady=10)
    
    add_prod_btn = Button(add_prod_frame,text="Add",bg="lightgreen",command=add_new_product,
    font="Courier 20 bold",width=10)
    add_prod_btn.grid(column=2,row=5)
    update_prod_btn = Button(add_prod_frame,text="Update",bg="yellow",command=update_product_data,
    font="Courier 20 bold",width=10)
    update_prod_btn.grid(column=1,row=5)
    Button(add_prod_frame,text="Delete",bg="darkred",font="Courier 20 bold",command=remove_product,
    fg='white',width=10).grid(column=0,row=5)
    Button(add_prod_frame,text="Back",bg="#ffe9d6",font="Courier 20 bold",command=back_from_prod_data,
    width=10).grid(column=0,row=6,columnspan=3)

    mytree_prod.bind('<Double-1>',treeviewclick_data_prod)

def search_product_click():  
    mytree_prod.delete(*mytree_prod.get_children())
    sql = "select * from product where product_id=?"
    cursor.execute(sql,[search_product.get()])
    result = cursor.fetchall()
    if result :
        for i,data in enumerate(result):
            mytree_prod.insert('','end',values=(data[0],data[1],data[2]))
        
def back_from_prod_data():
    add_prod_frame.destroy()
    login(root)

def treeviewclick_data_prod(event):
    prod_id_prod_data.delete(0,END)
    prod_name_prod_data.delete(0,END)
    prod_price_prod_data.delete(0,END)

    values_prod_data = mytree_prod.item(mytree_prod.focus(),'values')

    prod_id_prod_data.insert(0,values_prod_data[0])
    prod_name_prod_data.insert(0,values_prod_data[1])
    prod_price_prod_data.insert(0,values_prod_data[2])

def remove_product() :
    msg = messagebox.askquestion ('SYSTEM :','Are you sure you want to delete this product?',icon = 'warning')
    if msg == 'no':
        prod_id_prod_data.delete(0,END)
        prod_name_prod_data.delete(0,END)
        prod_price_prod_data.delete(0,END)
    else:
        deleterow = mytree_prod.selection()
        values = mytree_prod.item(mytree_prod.focus(),'values')
        mytree_prod.delete(deleterow)
        
        sql = "DELETE FROM product WHERE product_id=?"
        cursor.execute(sql,[values[0]])
        conn.commit()

        prod_id_prod_data.delete(0,END)
        prod_name_prod_data.delete(0,END)
        prod_price_prod_data.delete(0,END)

def update_product_data() :
    sql = '''UPDATE product
            SET product_name=?, product_price=?
            WHERE product_id=? '''
    cursor.execute(sql,[prod_name_prod_data.get(),prod_price_prod_data.get(),prod_id_prod_data.get()])  
    conn.commit()
    messagebox.showinfo("Product Record","UPDATE Successfully!")

def add_new_product() :
    sql = 'INSERT INTO product (product_id,product_name,product_price) VALUES (?,?,?)'
    cursor.execute(sql,[prod_id_prod_data.get(),prod_name_prod_data.get(),prod_price_prod_data.get()])
    conn.commit()
    messagebox.showinfo("New Product","Your New Product was added.")

root = main()
createconnection()
login(root)
clock()
search_logo = PhotoImage(file="img/search_tool.png").subsample(4,4)
prod_amt_box_var=StringVar()
payment_var=StringVar(value=0)
total_of_order=0
order_name_lst = []
order_price_lst = []
order_amt_lst = []
order_tt_lst = []
order_lst_sql = []
order_date_sql = []
order_tt_lst_sql=[]
mainloop()